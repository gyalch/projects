//
//  ViewController.swift
//  TestML
//
//  Created by Garrett Yalch on 9/3/19.
//  Copyright © 2019 Garrett Yalch. All rights reserved.
//

import UIKit
import AVKit
import CoreML
import Vision

class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
  
//CAMERA STUFF
    
    //referencing the imageview
    @IBOutlet weak var cameraView: UIImageView!
   
    //referencing the label
    @IBOutlet weak var resultText: UILabel!
    
    //when the view loads
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    setUpCamera()
    }
    //it will setup the camera when the view loads
    func setUpCamera() {
        guard let device = AVCaptureDevice.default(for: .video) else {return}
        guard let input = try? AVCaptureDeviceInput(device: device) else {return}
  
        let session = AVCaptureSession()
        session.sessionPreset = .hd1920x1080
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.frame = view.frame
        cameraView.layer.addSublayer(previewLayer)
    
        let output = AVCaptureVideoDataOutput()
        output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "CameraOutput"))
        
        session.addInput(input)
        session.addOutput(output)
        session.startRunning()
    }
 
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        
        guard let sampleBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else {return}
       
        scanImage(buffer: sampleBuffer)
    }
    
    func scaleAndRotateImage(image: UIImage, MaxResolution iIntMaxResolution: Int) -> UIImage {
        let kMaxResolution = iIntMaxResolution
        let imgRef = image.cgImage!
        let width: CGFloat = CGFloat(imgRef.width)
        let height: CGFloat = CGFloat(imgRef.height)
        var transform = CGAffineTransform.identity
        var bounds = CGRect.init(x: 0, y: 0, width: width, height: height)
        
        if Int(width) > kMaxResolution || Int(height) > kMaxResolution {
            let ratio: CGFloat = width / height
            if ratio > 1 {
                bounds.size.width = CGFloat(kMaxResolution)
                bounds.size.height = bounds.size.width / ratio
            }
            else {
                bounds.size.height = CGFloat(kMaxResolution)
                bounds.size.width = bounds.size.height * ratio
            }
        }
        let scaleRatio: CGFloat = bounds.size.width / width
        let imageSize = CGSize.init(width: CGFloat(imgRef.width), height: CGFloat(imgRef.height))
        
        var boundHeight: CGFloat
        let orient = image.imageOrientation
        // The output below is limited by 1 KB.
        // Please Sign Up (Free!) to remove this limitation.
        
        switch orient {
        case .up:
            //EXIF = 1
            transform = CGAffineTransform.identity
        case .upMirrored:
            //EXIF = 2
            transform = CGAffineTransform.init(translationX: imageSize.width, y: 0.0)
            transform = transform.scaledBy(x: -1.0, y: 1.0)
            
        case .down:
            //EXIF = 3
            transform = CGAffineTransform.init(translationX: imageSize.width, y: imageSize.height)
            transform = transform.rotated(by: CGFloat(Double.pi / 2))
            
        case .downMirrored:
            //EXIF = 4
            transform = CGAffineTransform.init(translationX: 0.0, y: imageSize.height)
            transform = transform.scaledBy(x: 1.0, y: -1.0)
        case .leftMirrored:
            //EXIF = 5
            boundHeight = bounds.size.height
            bounds.size.height = bounds.size.width
            bounds.size.width = boundHeight
            transform = CGAffineTransform.init(translationX: imageSize.height, y: imageSize.width)
            
            transform = transform.scaledBy(x: -1.0, y: 1.0)
            transform = transform.rotated(by: CGFloat(Double.pi / 2) / 2.0)
            break
            
        default: print("Error in processing image")
        }
        
        UIGraphicsBeginImageContext(bounds.size)
        let context = UIGraphicsGetCurrentContext()
        if orient == .right || orient == .left {
            context?.scaleBy(x: -scaleRatio, y: scaleRatio)
            context?.translateBy(x: -height, y: 0)
        }
        else {
            context?.scaleBy(x: scaleRatio, y: -scaleRatio)
            context?.translateBy(x: 0, y: -height)
        }
        context?.concatenate(transform)
        context?.draw(imgRef, in: CGRect.init(x: 0, y: 0, width: width, height: height))
        let imageCopy = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return imageCopy!
    }
    

//MACHINE LEARNING

    //creates a function that will do all of the image processing
    func scanImage (buffer: CVPixelBuffer) {
        
         //pulls in the model "imageclassifier.mlmodel"
        guard let model = try? VNCoreMLModel(for: ImageClassifier().model) else {return}

        //a vision thing that I don't totally understand
        let request = VNCoreMLRequest(model: model) { request, _ in
            guard let results = request.results as? [VNClassificationObservation] else {return}

        //the text that it displays in different scenarios
            guard let mostConfidentResult = results.first else {return}
            //confidenceText is the label that will show the confidence level of the Artificial Intelligence
            let confidenceText = "\n \(Int(mostConfidentResult.confidence * 100.0))% confidence"

            //place variables here
            DispatchQueue.main.async {
                // if its 73% confident it will give you what it thinks it is - mostConfidentResult
                if mostConfidentResult.confidence >= 0.73 {
                switch mostConfidentResult.identifier {
                //defining what it should do in the different cases, a switch statement will switch things on the fly based on whats happening
                case "Cat":
                    self.resultText.text = "Cat \(confidenceText)"
                case "Dog":
                    self.resultText.text = "Dog \(confidenceText)"
                case "Person":
                    self.resultText.text = "Person \(confidenceText)"
                default:
                    self.resultText.text = "Not in database"
                    }
                } else {self.resultText.text = "Not in database"

                }
            }
        }


    // a catch do statement that performs the operation and then catches the error and then prints an error if somthing goes wrong
        let requestHandler = VNImageRequestHandler(cvPixelBuffer: buffer, options: [:])
        
            do {try requestHandler.perform([request])}
            
            catch {print(error)
    }
}

}


